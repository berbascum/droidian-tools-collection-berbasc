#!/bin/bash
export PATH=/usr/bin:/usr/sbin
# This is what ADB did

# Edit scale in phoc.ini to be applied in the first boot.
sed -i 's/scale = 3/scale = 2/g' /usr/share/phosh/phoc.ini

