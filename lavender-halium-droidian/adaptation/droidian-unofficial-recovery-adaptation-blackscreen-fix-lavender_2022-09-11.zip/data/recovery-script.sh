#!/bin/bash
export PATH=/usr/bin:/usr/sbin
# This is what ADB did


